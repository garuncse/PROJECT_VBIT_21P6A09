const express = require('express');
const cors = require('cors');
const app = express();

// Enable CORS middleware
app.use(cors());

// Middleware to parse JSON
app.use(express.json());

// Sample route for sending money
app.post('/send-money', (req, res) => {
    const { recipient, amount, note } = req.body;

    // Validate request data
    if (!recipient || !amount || isNaN(amount)) {
        return res.status(400).json({ status: 'error', message: 'Invalid request data' });
    }

    // Simulate successful transaction response
    res.json({ status: 'success', message: `Sent ${amount} ETH to ${recipient}. Note: ${note || 'No note provided'}` });
});

// Start the server
const PORT = 8080;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
