from web3 import Web3

private_key = '0x0a907b78996fe075119b824f93572f6aceddaea0c8fe7be96c063081d2c6a051'  # Replace with your private key
web3 = Web3()

# Get address from private key
account = web3.eth.account.from_key(private_key)
from_address = account.address

print(f"Your Ethereum address (from_address): {from_address}")
