from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import os
import subprocess

app = Flask(__name__)

# Enable CORS for all routes
CORS(app)

# Path to the frontend folder
frontend_folder = os.path.join(app.root_path, 'frontend')

# Routes for serving frontend pages
@app.route('/')
def homepage():
    return send_from_directory(frontend_folder, 'homepage.html')

@app.route('/sendmoney')
def sendmoney():
    return send_from_directory(frontend_folder, 'sendmoney.html')

@app.route('/receivemoney')
def receivemoney():
    return send_from_directory(frontend_folder, 'receivemoney.html')

@app.route('/paybills')
def paybills():
    return send_from_directory(frontend_folder, 'paybills.html')

@app.route('/requestmoney')
def requestmoney():
    return send_from_directory(frontend_folder, 'requestmoney.html')

@app.route('/mobilerecharge')
def mobilerecharge():
    return send_from_directory(frontend_folder, 'mobilerecharge.html')

@app.route('/investments')
def investments():
    return send_from_directory(frontend_folder, 'investments.html')

@app.route('/wealth')
def wealth():
    return send_from_directory(frontend_folder, 'wealth.html')

@app.route('/insurance')
def insurance():
    return send_from_directory(frontend_folder, 'insurance.html')

# Endpoint for Send Money functionality
@app.route('/send_money', methods=['POST'])
def send_money():
    data = request.get_json()
    recipient_address = data.get('recipient_address')
    amount_eth = data.get('amount_eth')
    note = data.get('note')

    # Simulate transaction logic
    response = {
        "tx_hash": "0x1234567890abcdef",
        "status": "Success"
    }

    return jsonify(response)

# Endpoint for Iris Scan Simulation
@app.route('/start_iris_scan', methods=['POST'])
def start_iris_scan():
    try:
        # Call the iris_scan.py script to simulate the iris scan
        result = subprocess.run(['python', 'iris_scan.py'], capture_output=True, text=True)
        if "Iris scan completed successfully!" in result.stdout:
            return jsonify({"status": "success", "message": "Iris scan completed successfully!"})
        else:
            return jsonify({"status": "failure", "message": "Iris scan failed!"})
    except Exception as e:
        return jsonify({"status": "failure", "message": str(e)})

if __name__ == '__main__':
    # Start the Flask app on host 0.0.0.0 to make it accessible on the network
    app.run(debug=True, host='0.0.0.0', port=8080)
