import cv2

def iris_scan():
    print("Opening camera for iris scan...")
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Camera could not be opened!")
        return False

    print("Press 'q' to simulate iris scan completion.")
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        cv2.imshow("Iris Scan in Progress", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):  # Simulate successful scan
            print("Iris scan completed successfully!")
            cap.release()
            cv2.destroyAllWindows()
            return True

    cap.release()
    cv2.destroyAllWindows()
    return False

if __name__ == '__main__':
    if iris_scan():
        print("Iris scan completed successfully!")
    else:
        print("Iris scan failed.")
