const Web3 = require('web3');
const { abi } = require('../build/contracts/Payment.json'); // Path to your contract JSON
const contractAddress = '0xE6d3090b7D63B849A117EfFC5fa117a582A59bCD'; // Your contract address

const web3 = new Web3('http://localhost:8546'); // Connect to Ganache on port 8546

const contract = new web3.eth.Contract(abi, contractAddress);

const fromAddress = '0x9489332fC693F3374036FD36CbA939AF063D5267'; // Replace with your Ethereum address
const toAddress = '0x596Df940fCE2EBfBF75E8e967208299d7FaA81AE'; // Replace with the actual recipient's address
const amount = web3.utils.toWei('1', 'ether'); // Amount to send (example: 1 ether)
const message = 'Payment for services'; // Optional message

async function interact() {
    try {
        await contract.methods.makePayment(toAddress, amount, message).send({ from: fromAddress });
        console.log('Payment sent successfully');
    } catch (error) {
        console.error('Error interacting with contract:', error);
    }
}

interact();
