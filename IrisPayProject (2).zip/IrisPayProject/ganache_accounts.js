const Web3 = require('web3');

// Connect to Ganache
const web3 = new Web3('http://127.0.0.1:8546');

async function getAccounts() {
    const accounts = await web3.eth.getAccounts();
    console.log('Accounts and Private Keys:');
    accounts.forEach((account, index) => {
        const privateKey = web3.eth.accounts.wallet[index]?.privateKey;
        console.log(`Account ${index + 1}: ${account}`);
        console.log(`Private Key ${index + 1}: ${privateKey}`);
        console.log('-----------------------------------');
    });
}

getAccounts();
