from web3 import Web3

# Address to validate
address = '0x7f5Ee9249b31d3bFD6Eb89ac9383D365D4951964'
is_valid = Web3.is_checksum_address(address)

# Print the result
if is_valid:
    print(f"{address} is a valid checksummed Ethereum address.")
else:
    print(f"{address} is NOT a valid checksummed Ethereum address.")
