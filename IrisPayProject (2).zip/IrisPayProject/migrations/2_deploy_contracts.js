const Payment = artifacts.require("Payment");

module.exports = function(deployer) {
  // Deploy the Payment contract
  deployer.deploy(Payment);
};
