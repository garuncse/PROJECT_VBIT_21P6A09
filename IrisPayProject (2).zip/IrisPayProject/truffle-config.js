module.exports = {
  networks: {
    development: {
      host: "127.0.0.1",    // Localhost
      port: 8545,           // Updated port number
      network_id: "*",      // Match any network id
    },
  },

  compilers: {
    solc: {
      version: "0.8.0",    // Use Solidity version 0.8.0
      settings: {
        optimizer: {
          enabled: false,
          runs: 200
        },
        evmVersion: "istanbul"
      }
    }
  },

  // Other configurations...
};
